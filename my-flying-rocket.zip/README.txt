A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/xyPWaB.

 I'm trying to fly my Rocket to the Sky. Done with Pure CSS check it out it's like a game.